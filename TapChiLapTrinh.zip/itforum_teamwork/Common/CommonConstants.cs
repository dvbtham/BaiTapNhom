﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace itforum_teamwork.Common
{
    public static class CommonConstants
    {
        public static string CLIENT_USER_SESSION = "CLIENT_USER_SESSION";
        public static string ADMIN_USER_SESSION = "ADMIN_USER_SESSION";
        public static bool IsAjax = true;

    }
}